import React, { useState } from 'react';
import { Header } from './components/Layout/Header';
import { Sidebar } from './components/Layout/Sidebar';
import { MainDashboard } from './components/Dashboard/MainDashboard';

function App() {
  const [activeSection, setActiveSection] = useState('dashboard');

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <MainDashboard />;
      case 'ai-engine':
        return (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">AI Engine Deep Dive</h2>
            <p className="text-gray-600">Advanced AI configuration and monitoring tools</p>
          </div>
        );
      case 'analytics':
        return (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Advanced Analytics</h2>
            <p className="text-gray-600">Detailed performance metrics and insights</p>
          </div>
        );
      case 'users':
        return (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">User Management</h2>
            <p className="text-gray-600">User profiles and behavior analysis</p>
          </div>
        );
      case 'personalization':
        return (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Personalization Settings</h2>
            <p className="text-gray-600">Fine-tune AI personalization algorithms</p>
          </div>
        );
      case 'cultural-ai':
        return (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Cultural AI</h2>
            <p className="text-gray-600">Indonesian cultural preferences and localization</p>
          </div>
        );
      case 'sentiment':
        return (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Sentiment Analysis</h2>
            <p className="text-gray-600">Real-time emotional intelligence and mood tracking</p>
          </div>
        );
      case 'behavior':
        return (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Behavior Analytics</h2>
            <p className="text-gray-600">Deep behavioral pattern analysis</p>
          </div>
        );
      case 'optimization':
        return (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">AI Optimization</h2>
            <p className="text-gray-600">Performance tuning and algorithm optimization</p>
          </div>
        );
      case 'settings':
        return (
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Settings</h2>
            <p className="text-gray-600">Platform configuration and preferences</p>
          </div>
        );
      default:
        return <MainDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <Header />
      <div className="flex">
        <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
        <main className="flex-1 p-8">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;